@extends('layout.default')

@section('main')

<p>
    <a href="connexion">Click here</a>
</p>

@endsection