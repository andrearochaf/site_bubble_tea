# Groupe de gueye_d 970968

# Gestionnaire de tâches BubbleMyTea

Mise en place du gestionnaire de tâches.

Mise en place du diagramme UML pour la base de données.

Mise en place du Project Schedule Network Diagramme.

Création du logo.

Mise en place de la base de données à travers les migrations et les modèles.

Mise en place des api (Application Program Interface) avec les contrôleurs.

Créer les vues & routes des pages connexion et inscription.

Créer la vue & route de la page admin.

Créer la vue & route de la page d'accueil du client.

Créer la vue & route de la page d'affichage des produits.

Créer la vue & route de la page de chaque produit.

Mise en place de la gestion du panier.
